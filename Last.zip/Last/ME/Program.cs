﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

using System.Text;
using System.Threading.Tasks;

using static System.Console;
using static System.Math;

namespace ME
{
    class Program
    {
        static double f(double x, double y) => Sin(5 * x) / 3 + Cos(3 * y) / 5;
        public static void Example()
        {
            var T = Triangulation.Circle(3);
            var p = T.x.Zip(T.y, (x, y) => string.Format($"{x} {y} {f(x, y)} "));
            var tri = T.tri.Select(t => string.Format($"{t[0]} {t[1]} {t[2]} "));
            var off = Enumerable.Range(0, T.tri.Length).Select(t => string.Format($"{3 * (t + 1)} "));
            var tp = Enumerable.Range(0, T.tri.Length).Select(t => "5 ");
            var points = new XElement("Points", new XElement("DataArray", new XAttribute("type", "Float64"), new XAttribute("NumberOfComponents", "3"), new XAttribute("format", "ascii"), p));

            var triangles = new XElement("Cells", new XElement("DataArray", new XAttribute("type", "UInt32"), new XAttribute("Name", "connectivity"), new XAttribute("format", "ascii"), tri),
                                                  new XElement("DataArray", new XAttribute("type", "UInt32"), new XAttribute("Name", "offsets"), new XAttribute("format", "ascii"), off),
                                                  new XElement("DataArray", new XAttribute("type", "UInt8"), new XAttribute("Name", "types"), new XAttribute("format", "ascii"), tp));

            var xdoc = new XDocument(new XElement("VTKFile", new XAttribute("type", "UnstructuredGrid"), new XAttribute("version", "0.1"),
                                     new XElement("UnstructuredGrid",
                                        new XElement("Piece", new XAttribute("NumberOfPoints", T.x.Length), new XAttribute("NumberOfCells", T.tri.Length),
                                        points,
                                        triangles))));


            //WriteLine(xdoc);
            xdoc.Save("tri.vtu");

            var matlab = new MLApp.MLApp();
            matlab.PutWorkspaceData("x", "base", T.x);
            matlab.PutWorkspaceData("y", "base", T.y);
            var mtri = new double[T.tri.Length, T.tri[0].Length];
            for (int i = 0; i < mtri.GetLength(0); i++)
                for (int j = 0; j < mtri.GetLength(1); j++)
                    mtri[i, j] = T.tri[i][j] + 1;
            matlab.PutWorkspaceData("tri", "base", mtri);
            matlab.Execute("triplot(tri,x,y); axis equal");
            ReadKey();
            //Process.Start("\""+ @"C:\Program Files\ParaView 5.6.0-Windows-msvc2015-64bit\bin\paraview.exe" + "\"");
        }

        static void Main(string[] args)
        {
            Example();
        }
    }
}
