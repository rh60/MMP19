﻿using System.Collections.Generic;
using static System.Math;

namespace ME
{
    public class Triangulation
    {
        public static double tol = 1E-7;
        public double[] x, y;
        public int[][] tri;

        public struct Edge
        {
            public int i1, i2;
            public Edge(int i1, int i2)
            {
                if (i1 < i2)
                {
                    this.i1 = i1;
                    this.i2 = i2;
                }
                else
                {
                    this.i2 = i1;
                    this.i1 = i2;
                }
            }
        }
        public class Triangle
        {
            public int[] i;
            public IEnumerable<Edge> Edges
            {
                get
                {
                    yield return new Edge(i[0], i[1]);
                    yield return new Edge(i[1], i[2]);
                    yield return new Edge(i[2], i[0]);
                }
            }
        }

        public static Triangulation Circle(int n)
        {
            double b = Sqrt(3) / 2, a = 0.5;
            double[] x0 = { 0, 1, a, -a, -1, -a, a  };
            double[] y0 = { 0, 0, b, b, 0, -b, -b };
            double[] r0 = { 0, 1, 1, 1, 1, 1, 1 };
            var lx = new List<double>(x0);
            var ly = new List<double>(y0);
            var lr = new List<double>(r0);
            var lt = new List<int[]>();
            for (int i = 0; i < 5; i++)
                lt.Add(new int[] { 0, i + 1, i + 2 });
            lt.Add(new int[] { 0, 6, 1 });
            var ie = new List<int>(3);
            var edges = new Dictionary<Edge, int>();
            for (int i = 0; i < n; i++)
            {
                var lt2 = new List<int[]>();
                edges.Clear();
                foreach (var it in lt)
                {
                    var T = new Triangle { i = it };
                    ie.Clear();
                    foreach (var e in T.Edges) Mid(e);
                    lt2.Add(new int[] { ie[0], ie[1], ie[2] });
                    lt2.Add(new int[] { it[0], ie[0], ie[2] });
                    lt2.Add(new int[] { it[1], ie[1], ie[0] });
                    lt2.Add(new int[] { it[2], ie[2], ie[1] });
                }             
                lt = lt2;
            }

            return new Triangulation { x = lx.ToArray(), y = ly.ToArray(), tri = lt.ToArray() };

            void Mid(Edge e)
            {
                int i;
                if (edges.ContainsKey(e))                
                    i = edges[e];           
                else
                {
                    var x = (lx[e.i1] + lx[e.i2]) / 2;
                    var y = (ly[e.i1] + ly[e.i2]) / 2;
                    var r = Sqrt(x * x + y * y);
                    var r1 = lr[e.i1];
                    if (Abs(r1 - lr[e.i2]) < tol)
                    {
                        var d = r1 / r;
                        x *= d;
                        y *= d;
                        r = r1;
                    }
                    i = lx.Count;
                    lx.Add(x); ly.Add(y); lr.Add(r);
                    edges.Add(e, i);
                }
                ie.Add(i);
            }
        }        
    }
}
